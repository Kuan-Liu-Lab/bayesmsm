## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = 'center',
  fig.width = 9,
  fig.height = 6,
  warning = F,
  message = F
)

## ----warning = FALSE, results=FALSE, force=TRUE-------------------------------
devtools::install_github("Kuan-Liu-Lab/bayesmsm")
library(bayesmsm)

## -----------------------------------------------------------------------------
library(DiagrammeR)
grViz("
    digraph causal {
    # Nodes
    node [shape=plaintext]
    W [label = 'w1, w2']
    L1 [label = 'L11, L21']
    Z1 [label = 'Z1']
    L2 [label = 'L12, L22']
    Z2 [label = 'Z2']
    Y [label = 'Y']
    
    # Edges
    edge [color=black, arrowhead=vee]
    rankdir = LR
    W->L1
    W->Z1
    W->L2
    W->Z2
    W->Y
    L1->Z1
    L1->L2
    L1->Z2
    L1->Y
    Z1->L2
    Z1->Z2
    Z1->Y
    L2->Z2
    L2->Y
    Z2->Y
    
    # Graph
    graph [overlap=true, fontsize=14]
    }")

## -----------------------------------------------------------------------------
library(DT)
options(scipen = 999)

testdata <- read.csv(system.file("extdata", "continuous_outcome_data.csv", package = "bayesmsm"))

# look at the data;
datatable(testdata,
          rownames = FALSE,
          options = list(dom = 't')) %>%
  formatRound(columns=c('w2', 'L2_1', 'L2_2', 'y'), digits=2)

## -----------------------------------------------------------------------------
# frequency counts by treatment combinations;
table(testdata$a_1, testdata$a_2)

## -----------------------------------------------------------------------------
weights <- bayesweight(trtmodel.list = list(a_1 ~ w1 + w2 + L1_1 + L2_1,
                                             a_2 ~ w1 + w2 + L1_1 + L2_1 + L1_2 + L2_2 + a_1),
                        data = testdata,
                        n.iter = 2000,
                        n.burnin = 1000,
                        n.thin = 5,
                        n.chains = 2,
                        seed = 890123,
                        parallel = TRUE)
str(weights)

## -----------------------------------------------------------------------------
model <- bayesmsm(ymodel = y ~ a_1+a_2,
                           nvisit = 2,
                           reference = c(rep(0,2)),
                           comparator = c(rep(1,2)),
                           family = "gaussian",
                           data = testdata,
                           wmean = weights,
                           nboot = 1000,
                           optim_method = "BFGS",
                           parallel = TRUE,
                           seed = 890123,
                           ncore = 2)
str(model)

## -----------------------------------------------------------------------------
plot_ATE(model)

## -----------------------------------------------------------------------------
plot_APO(model, "effect_reference")
plot_APO(model, "effect_comparator")

## -----------------------------------------------------------------------------
plot_est_box(model)


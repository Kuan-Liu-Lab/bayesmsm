## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = 'center',
  fig.width = 9,
  fig.height = 6,
  warning = F,
  message = F
)

## ----warning = FALSE, results=FALSE, force=TRUE-------------------------------
devtools::install_github("Kuan-Liu-Lab/bayesmsm")
library(bayesmsm)

## -----------------------------------------------------------------------------
# simulating causal data with censoring;
simdat_cen <- read.csv(system.file("extdata", "sim_causal.csv", package = "bayesmsm"))

# look at the data;
head(simdat_cen)

## -----------------------------------------------------------------------------
weights <- bayesweight_cen(trtmodel.list = list(A1 ~ L11 + L21,
                                                A2 ~ L11 + L21 + L12 + L22 + A1,
                                                A3 ~ L11 + L21 + L12 + L22 + A1 + L13 + L23 + A2),
                           cenmodel.list = list(C1 ~ L11 + L21,
                                                C2 ~ L11 + L21 + A1,
                                                C3 ~ L11 + L21 + A1 + L12 + L22 + A2),
                           data = simdat_cen,
                           n.iter = 250,
                           n.burnin = 150,
                           n.thin = 1,
                           n.chains = 1,
                           seed = 890123,
                           parallel = FALSE)
summary(weights)

## -----------------------------------------------------------------------------
# Remove all NAs (censored observations) from the original dataset and weights
simdat_cen <- na.omit(simdat_cen)
weights <- na.omit(weights)

model <- bayesmsm(ymodel = Y ~ A1+A2+A3,
                  nvisit = 3,
                  reference = c(rep(0, 3)),
                  comparator = c(rep(1, 3)),
                  family = "binomial",
                  data = simdat_cen,
                  wmean = weights,
                  nboot = 100,
                  optim_method = "BFGS",
                  parallel = FALSE,
                  seed = 890123,
                  ncore = 1)
str(model)

## -----------------------------------------------------------------------------
# Extract results
head(model$bootdata)

## -----------------------------------------------------------------------------
plot_ATE(model)

## -----------------------------------------------------------------------------
plot_APO(model, effect_type = "effect_comparator")
plot_APO(model, effect_type = "effect_reference")

## -----------------------------------------------------------------------------
plot_est_box(model)

## -----------------------------------------------------------------------------
summary_bayesmsm(model)


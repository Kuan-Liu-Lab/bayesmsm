if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("chain_idx"))
  utils::globalVariables(c("x", "y", "Treatment", "Mean", "LowerCI", "UpperCI"))
  utils::globalVariables(c("model_string"))
}
